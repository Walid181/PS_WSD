package testCases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import base.DriverSetup;

public class Product extends DriverSetup {
	@Test
	public void product() throws InterruptedException {
	String baseUrllast = "https://practicesoftwaretesting.com/";
	
	
	driver.get(baseUrllast);
	driver.manage().window().maximize();
	Thread.sleep(2000);
	//new WebDriverWait(driver,Duration.ofSeconds(10));
	
	
	WebElement combination_pilers=driver.findElement(By.xpath("//img[@alt='Combination Pliers']"));
	combination_pilers.click();
	
	Thread.sleep(4000);
	new WebDriverWait(driver,Duration.ofSeconds(5));
	
	WebElement addtocart=driver.findElement(By.xpath("//button[@id='btn-add-to-cart']"));
	addtocart.click();
	
	
	WebElement productadded=driver.findElement(By.xpath("//body/app-root/div[@class='container']/app-detail/div[@class='row my-3']/div[2]"));
	String pas=productadded.getText();
	new WebDriverWait(driver,Duration.ofSeconds(5));
	System.out.println("Success Message is product name"+""+pas);
	
	
	WebElement productcount=driver.findElement(By.xpath("//button[@id='btn-increase-quantity']//fa-icon[@class='ng-fa-icon']//*[name()='svg']"));
	productcount.click();
	Thread.sleep(1000);
	productcount.click();
	Thread.sleep(2000);
	
	WebElement productaddedcheck=driver.findElement(By.xpath("//body/app-root/div[@class='container']/app-detail/div[@class='row my-3']/div[2]"));
	String pass=productadded.getText();
	
	System.out.println("Product price is same. price dont get Updated");
	
	
}
}


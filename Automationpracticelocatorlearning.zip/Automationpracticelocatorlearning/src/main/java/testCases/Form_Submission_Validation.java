package testCases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.JavascriptExecutor;



import base.DriverSetup;

public class Form_Submission_Validation extends DriverSetup {
	String baseUrl = "https://practicesoftwaretesting.com/";

	@Test(priority=1)
	public void Form_Submission_validation() throws InterruptedException {

		driver.get(baseUrl);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement contact_form=driver.findElement(By.xpath("//*[text()='Contact']"));
		
		//new WebDriverWait(driver,Duration.ofSeconds(10));
		contact_form.click();
		Thread.sleep(2000);
		
		
		
		WebElement send=driver.findElement(By.xpath("//input[@value='Send']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", send);
		send.click();
		
		Thread.sleep(6000);
		
		WebElement First_Name_Validation_Error=driver.findElement(By.xpath("//div[contains(text(),'First name is required')]"));
		String text_first_name=First_Name_Validation_Error.getText();
		System.out.println("First_Name_Validation_Error Text is"+""+text_first_name);
		
		WebElement Last_name_Validation_Error=driver.findElement(By.xpath("//div[contains(text(),'Last name is required')]"));
		
	String text_last_name=Last_name_Validation_Error.getText();
	
	System.out.println("last name validation error is"+""+text_last_name);
	
	
		
		
		
		
		
		
		
		
	}
	
	String base_url2="https://practicesoftwaretesting.com/contact";
	@Test(priority =2)
	public void form_submission() throws InterruptedException {
		driver.get(base_url2);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		new WebDriverWait(driver,Duration.ofSeconds(10));
		
		WebElement first_name=driver.findElement(By.xpath("//input[@id='first_name']"));
		first_name.sendKeys("Walid ");
		Thread.sleep(2000);
		
		WebElement last_name=driver.findElement(By.xpath("//input[@id='last_name']"));
		last_name.sendKeys("Hasan");
		Thread.sleep(2000);
		
		WebElement Email=driver.findElement(By.xpath("//input[@id='email']"));
		Email.sendKeys("arnobhasan186@gmail.com");
		Thread.sleep(4000);
		
		WebElement Subject=driver.findElement(By.xpath("(//select[@id='subject'])"));
		
				Select select = new Select(Subject);
				
				select.selectByIndex(2);
				Thread.sleep(2000);
		
		WebElement message=driver.findElement(By.xpath("//textarea[@id='message']"));
		message.sendKeys("Hi, Congratulations. this is Walid Hasan Arnob from bangladesh. I am a sqa engineer with 3 years of experience. I have expertise in manual and automation testing.");
		Thread.sleep(2000);
		
		
		WebElement send=driver.findElement(By.xpath("//input[@value='Send']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", send);
		send.click();
		Thread.sleep(5000);
		
		WebElement success_mz=driver.findElement(By.xpath("//div[@role='alert']"));
		String sz=success_mz.getText();
		
		System.out.println("Success Mz is"+""+sz);
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
}
		
